import{c as o}from"./createLucideIcon-DMCpqgmY.js";import"./index-CcldLidV.js";const t=[["path",{d:"M5 12h14",key:"1ays0h"}]],s=o("minus",t);export{t as __iconNode,s as default};

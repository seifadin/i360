import{c as o}from"./createLucideIcon-DMCpqgmY.js";import"./index-CcldLidV.js";const t=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],r=o("chevron-right",t);export{t as __iconNode,r as default};

import{c}from"./createLucideIcon-DMCpqgmY.js";import"./index-CcldLidV.js";const e=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],a=c("check",e);export{e as __iconNode,a as default};

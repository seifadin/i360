import{c as o}from"./createLucideIcon-DMCpqgmY.js";import"./index-CcldLidV.js";const t=[["path",{d:"M22 2 2 22",key:"y4kqgn"}]],e=o("slash",t);export{t as __iconNode,e as default};

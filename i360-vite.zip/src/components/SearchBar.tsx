import { useRef, useState } from 'react'
import {
  Search, Bot, Keyboard,
  PencilSparkles, Minimize2, Languages, BookSearch,
  CircleAlert, CircleQuestionMark, CircleX,
} from 'lucide-react'
import { useAppState } from '@/store/appState'
import { useDataCache } from '@/store/dataCache'
import { isArabic, translateToArabic } from '@/api/translator'
import { computeUseHuawei } from '@/hooks/usePlatform'
import { tryOpenNewTab } from '@/lib/openTab'
import { openResource } from '@/lib/openResource'
import { i360Theme } from '@/lib/theme'

// Icon mapping confirmation:
// Search   → search icon inside input LEFT side
// Bot      → AI assistant outside input LEFT of it
// Keyboard → virtual keyboard outside leftmost

// Strict full-string match only — a substring like "تفسير آية 2.255" does NOT
// trigger exegesis, only a pure digits.digits string does.
const EXEGESIS_PATTERN = /^\d+\.\d+$/

// 'invalid': malformed chapter.verse input (exegesis only).
// 'notfound': valid input, but no exegesis match exists (exegesis only) —
// genuinely "no matching data," distinct from an open failure below.
// 'openfailed': the browser action itself failed (e.g. a blocked popup) — any
// path that opens via openResource().
type FlashIcon = 'invalid' | 'notfound' | 'openfailed' | null
type SearchPhase = 'translating' | 'opening' | null

// Small reusable brief-flash helper for Bot/Keyboard — they have no other
// icon states, just "normal" vs. "briefly show a failure icon."
function useBriefFlash(durationMs = 500): [boolean, () => void] {
  const [active, setActive] = useState(false)
  function trigger() {
    setActive(true)
    setTimeout(() => setActive(false), durationMs)
  }
  return [active, trigger]
}

const FLASH_MS = 500 // how long a status icon flashes

export default function SearchBar() {
  const { state } = useAppState()
  const { resource, findExegesisUrl } = useDataCache()

  const [EntityQueryTerm, setEntityQueryTerm] = useState('')
  // One submit at a time: blocks double-taps while a search/exegesis open is
  // in flight (translation can take seconds). A ref, not state — two quick
  // taps can both land before a state update. Repeating a finished search is
  // allowed, e.g. after closing the results.
  const busyRef = useRef(false)

  // One-shot forced-search-only override — armed by tapping SearchIcon.
  // Bypasses pattern detection for the NEXT submission only, then reverts.
  const [overrideArmed, setOverrideArmed] = useState(false)

  // Brief post-submit flash (~500ms) — overrides the live icon momentarily
  // to signal invalid input or no exegesis match, then reverts automatically.
  const [flash, setFlash] = useState<FlashIcon>(null)

  // Two distinct in-flight phases for the custom-search path:
  // 'translating' (Languages) — only for non-Arabic text, during the MS
  // Translator call. 'opening' (BookSearch) — always, while resolving/opening
  // the URL. Arabic text skips straight to 'opening'. Never used for the
  // exegesis path, which is a synchronous local lookup with no "in flight" state.
  const [searchPhase, setSearchPhase] = useState<SearchPhase>(null)

  const trimmed = EntityQueryTerm.trim()
  // chapter.verse may be typed in any of the three digit sets (Arabic
  // keyboards often give ٠١٢٣ by default), and with the Arabic decimal
  // separator ٫ — read as Western digits and a dot (2026-10-21, §15t).
  // Only the exegesis check uses this; a search sends what was typed.
  const exegesisTerm = i360Theme.toNumerals(trimmed, 'western').replace(/٫/g, '.')
  const isExegesisMatch = EXEGESIS_PATTERN.test(exegesisTerm)

  function handleSearchIconTap() {
    setOverrideArmed(prev => !prev)
  }

  function flashIconFor(kind: 'invalid' | 'notfound' | 'openfailed') {
    setFlash(kind)
    setTimeout(() => setFlash(null), FLASH_MS)
  }

  const [botFailed, triggerBotFailed] = useBriefFlash()
  const [keyboardFailed, triggerKeyboardFailed] = useBriefFlash()

  // Keyboard + Bot URLs — derived from the cached i360dbc record (no fetch here)
  const useHuawei = computeUseHuawei(state.useWeb, state.isChina, state.useHMS)
  const keyboardUrl = (useHuawei ? resource?.Huawei_VirtualKeyboard : resource?.Google_VirtualKeyboard) ?? ''
  const botUrl = (useHuawei ? resource?.Huawei_BotSearch : resource?.BotSearch) ?? ''

  // Where a URL opens: one shared decision (lib/openResource.ts). It now
  // reports in-app browser failures too, so 'openfailed' is truthful there.
  const openCtx = { useWeb: state.useWeb, uriSchemes: resource?.URIschemes ?? '', inWebList: resource?.inWebList ?? '' }

  async function handleSubmit() {
    if (!trimmed) {
      flashIconFor('invalid')
      return
    }

    if (busyRef.current) return
    busyRef.current = true

    const routeToExegesis = !overrideArmed && isExegesisMatch
    if (overrideArmed) setOverrideArmed(false) // one-shot — consumed on submit

    try {
      if (routeToExegesis) {
        await handleExegesisSubmit(exegesisTerm)
      } else {
        await handleSearch()
      }
    } finally {
      busyRef.current = false
    }
  }

  // fExegesis-equivalent — chapter.verse dot format, chapter=split[0], verse=split[1]
  async function handleExegesisSubmit(value: string) {
    const [chapterStr, verseStr] = value.split('.')
    const chapter = Number(chapterStr)
    const verse = Number(verseStr)

    if (!Number.isFinite(chapter) || !Number.isFinite(verse) || chapter <= 0 || verse < 0) {
      flashIconFor('invalid')
      return
    }

    // Dot-to-colon normalization — kept for possible future use (e.g. matching
    // tanzil.net's Chapter:Verse convention): `${chapter}:${verse}`.
    // Not currently consumed by anything, so not computed here to avoid dead code.

    const url = findExegesisUrl(chapter, verse)

    if (!url) {
      flashIconFor('notfound')
      return
    }

    const opened = await openResource(url, openCtx)
    if (!opened) flashIconFor('openfailed')
  }

  // fSearchCustom-equivalent. Choreography: Arabic text → BookSearch while
  // opening, then reverts. Non-Arabic text → Languages while translating,
  // then BookSearch while opening, then reverts. CircleX flash only on a
  // genuine open failure. CustomSearch/Huawei_CustomSearch (search engine cx)
  // and Translator (translator endpoint URL) are read from cached i360dbc —
  // wired up this session; both fall back to their VITE_* env var if the
  // Baserow field is empty/not yet loaded.
  async function handleSearch() {
    // The trimmed value throughout, as handleSubmit validated it — no stray
    // spaces in the translation or the search URL.
    if (!trimmed) return

    let arabicTerm = trimmed
    if (!isArabic(trimmed)) {
      setSearchPhase('translating')
      try { arabicTerm = await translateToArabic(trimmed, resource?.Translator) }
      catch { arabicTerm = trimmed }
    }

    setSearchPhase('opening')
    // Baserow's CustomSearch/Huawei_CustomSearch is a complete search-URL
    // template ending in Google CSE's fragment convention (#gsc.q=), meant
    // to have the query appended directly — NOT a bare cx value for a
    // standard ?q= query string, which is a different (and wrong) URL shape.
    // The env-var fallback is built in the same template shape from the cx
    // alone, for consistency with what's actually configured in Baserow.
    const csTemplate = (useHuawei ? resource?.Huawei_CustomSearch : resource?.CustomSearch)
      || `https://cse.google.com/cse?cx=${import.meta.env.VITE_PSE_CX}#gsc.tab=0&gsc.sort=&gsc.q=`
    const pseUrl = `${csTemplate}${encodeURIComponent(arabicTerm)}`
    const opened = await openResource(pseUrl, openCtx)

    setSearchPhase(null)
    if (!opened) flashIconFor('openfailed')
  }

  async function handleBot() {
    if (!botUrl) return
    const opened = await openResource(botUrl, openCtx, 'bot')
    if (!opened) triggerBotFailed()
  }

  // Keyboard links are native-app deep links (install/open a keyboard app,
  // or device keyboard settings) — not browsable web pages. Always opens
  // externally, never routes through the useWeb-aware WebView logic.
  function handleKeyboard() {
    if (!keyboardUrl) return
    if (!tryOpenNewTab(keyboardUrl)) triggerKeyboardFailed()
  }

  // Accessible name for the search-options button — mirrors the icon choice
  // below, so screen readers get what the changing icon shows. transientStatus is
  // shared by both values (same state, same messages); null when nothing
  // transient applies, so each ?? falls through to its own default.
  const transientStatus: string | null =
    flash === 'invalid' ? 'إدخال غير صالح' :
    flash === 'notfound' ? 'لم يتم العثور على تفسير لهذه الآية' :
    flash === 'openfailed' ? 'تعذر فتح الرابط' :
    searchPhase === 'translating' ? 'جارٍ الترجمة' :
    searchPhase === 'opening' ? 'جارٍ فتح النتائج' :
    null

  const searchIconLabel = transientStatus ?? (
    overrideArmed ? 'وضع البحث المباشر مفعّل، اضغط للإلغاء' :
    isExegesisMatch ? 'تم اكتشاف رقم آية، اضغط للبحث العادي بدلاً من ذلك' :
    'خيارات البحث'
  )

  // Separate from the button label above: covers only the genuinely
  // transient/ephemeral events (500ms flashes, in-flight phases, plus
  // Bot/Keyboard's own failures) that need proactive announcement
  // regardless of what currently has focus — e.g. an "invalid input"
  // flash appears on THIS icon after tapping Submit, a different button,
  // so nothing here would otherwise reach a screen reader unless it's
  // wrapped in a live region. Empty string when nothing transient is
  // happening, so the live region stays silent by default.
  const liveMessage = transientStatus ?? (
    botFailed ? 'تعذر فتح المساعد الذكي' :
    keyboardFailed ? 'تعذر فتح لوحة المفاتيح' :
    ''
  )

  return (
    <div className="flex items-center gap-2 px-3 py-2 bg-brand-ivory border-b border-brand-border">
      {/* Visually hidden, announces the transient states above regardless
          of which element currently has focus. role="status" + explicit
          aria-live="polite" together for the broadest, most reliable
          screen-reader support. */}
      <span className="sr-only" role="status" aria-live="polite">{liveMessage}</span>

      {/* Search input with SearchIcon (right) + Search-execute icon (left) */}
      <div className="flex flex-1 min-w-0 items-center rounded-full border border-brand-border bg-brand-input px-3 py-1 gap-2">
        {/* SearchIcon — live 3-state indicator + one-shot override control.
            PencilSparkles: auto-detect, input doesn't match (resting/default,
            including empty input). Tapping while empty flashes CircleAlert.
            Languages: auto-detect, input matches chapter.verse live — OR
            custom-search translating a non-Arabic term (in flight).
            Minimize2: forced search-only override armed (tap to arm/disarm).
            BookSearch: custom search opening the resolved URL (in flight). */}
        <button
          onClick={handleSearchIconTap}
          className="shrink-0 text-brand-blue"
          aria-label={searchIconLabel}
        >
          {flash === 'invalid' && <CircleAlert size={17} />}
          {flash === 'notfound' && (
            <CircleQuestionMark size={17} className="-scale-x-100" />
          )}
          {flash === 'openfailed' && <CircleX size={17} />}
          {!flash && searchPhase === 'translating' && <Languages size={17} />}
          {!flash && searchPhase === 'opening' && <BookSearch size={17} />}
          {!flash && !searchPhase && overrideArmed && <Minimize2 size={17} />}
          {!flash && !searchPhase && !overrideArmed && isExegesisMatch && <Languages size={17} />}
          {!flash && !searchPhase && !overrideArmed && !isExegesisMatch && <PencilSparkles size={17} />}
        </button>

        <input
          type="text"
          id="i360-search"
          name="search"
          value={EntityQueryTerm}
          onChange={e => setEntityQueryTerm(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSubmit()}
          placeholder="بحث ... أو الآية#.السورة#"
          aria-label="بحث"
          // Standard form pattern found on closer review, alongside the
          // three findings above: many screen readers announce "invalid
          // entry" automatically when a focused field has aria-invalid
          // true. Only ever true for the same brief 500ms window the
          // invalid-input flash shows, then clears itself with it.
          aria-invalid={flash === 'invalid'}
          className="min-w-0 flex-1 bg-transparent text-right text-base text-brand-blue outline-none placeholder-brand-muted"
          dir="rtl"
        />
        {/* Search icon inside input on LEFT (last in RTL flex = leftmost) */}
        <button onClick={handleSubmit} className="shrink-0 text-brand-blue" aria-label="بحث">
          <Search size={17} />
        </button>
      </div>

      {/* Bot — outside input LEFT */}
      <button
        onClick={handleBot}
        className={`shrink-0 p-1 ${botUrl ? 'text-brand-blue' : 'text-brand-disabled'}`}
        disabled={!botUrl}
        aria-label="المساعد الذكي"
      >
        {botFailed ? <CircleX size={20} /> : <Bot size={20} />}
      </button>

      {/* Keyboard — leftmost */}
      <button
        onClick={handleKeyboard}
        className={`shrink-0 p-1 ${keyboardUrl ? 'text-brand-blue' : 'text-brand-disabled'}`}
        disabled={!keyboardUrl}
        aria-label="لوحة المفاتيح"
      >
        {keyboardFailed ? <CircleX size={20} /> : <Keyboard size={20} />}
      </button>
    </div>
  )
}

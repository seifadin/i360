fastlane documentation
----

# Installation

Make sure you have the latest version of the Xcode command line tools installed:

```sh
xcode-select --install
```

For _fastlane_ installation instructions, see [Installing _fastlane_](https://docs.fastlane.tools/#installing-fastlane)

# Available Actions

## Android

### android build_release

```sh
[bundle exec] fastlane android build_release
```

Build a signed release AAB, ready to upload manually to Google Play / AppGallery Connect

### android deploy_google

```sh
[bundle exec] fastlane android deploy_google
```

Build and submit to Google Play production

### android deploy_huawei

```sh
[bundle exec] fastlane android deploy_huawei
```

Build and submit to Huawei AppGallery

----

This README.md is auto-generated and will be re-generated every time [_fastlane_](https://fastlane.tools) is run.

More information about _fastlane_ can be found on [fastlane.tools](https://fastlane.tools).

The documentation of _fastlane_ can be found on [docs.fastlane.tools](https://docs.fastlane.tools).
